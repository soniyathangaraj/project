package com.cg.event.bean;

import java.time.LocalDate;

public class BookingBean {
	private String bookingId;
	private String eventName;
	private double totalCost;
	LocalDate date;
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public double getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "BookingBean [bookingId=" + bookingId + ", eventName=" + eventName + ", totalCost=" + totalCost
				+ ", date=" + date + "]";
	}
	

}
