package com.cg.event.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.cg.event.bean.EventBean;
import com.cg.event.exception.EventException;
import com.cg.event.util.DBConnection;

public class EventDaoImpl implements IEventDao {

	@Override
	public String addEvent(EventBean event) throws EventException {
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String customerId=null;
		int queryResult=0;
		
		try {
			preparedStatement=connection.prepareStatement("insert into Customer_Details values(customerId.nextVal,?,?,?,?,SYSDATE)");
			preparedStatement.setString(1,event.getCustomerName());
			preparedStatement.setString(2,event.getPhoneNumber());
			preparedStatement.setString(3,event.getAddress());
			
			preparedStatement.setDouble(4, event.getPayAmount());
			preparedStatement.executeUpdate();
			Statement st=null;
			st=connection.createStatement();
			
			
			resultSet=st.executeQuery("select max(customerId) from  Customer_Details");
		while(resultSet.next())
			{
			
				customerId=resultSet.getString(1);
			}
		}
		catch(Exception sql)
		{
			System.out.println(sql);
			sql.printStackTrace();
		}
		
		try {
			
			 resultSet.close();
			 preparedStatement.close();
			
			connection.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	
		return customerId;
	}

	

	@Override
	public EventBean viewEventDetails(String customerId) throws EventException, SQLException {
		
		
		Connection connection=DBConnection.getConnection();
		ResultSet resultSet=null;
		Statement st=null;
		
		EventBean eventBean=new EventBean();
		st=connection.createStatement();
		resultSet=st.executeQuery("select * from customer_details where customerid="+customerId+"");
		while(resultSet.next())
		{
			
			eventBean.setCustomerId(resultSet.getString(1));
			eventBean.setCustomerName(resultSet.getString(2));
			eventBean.setPhoneNumber(resultSet.getString(3));
			eventBean.setAddress(resultSet.getString(4));
			
			
			eventBean.setPayAmount(resultSet.getInt(5));
			eventBean.setBookingDate(resultSet.getDate(6));
		}
		
		return eventBean;
		
	}

	@Override
	public List retrieveAll() throws EventException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getConnection();
		int eventCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<EventBean> eventList=new ArrayList<EventBean>();
		try
		{
			ps=con.prepareStatement("SELECT * FROM customer_details");
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				EventBean eventBean=new EventBean();
				eventBean.setCustomerId(resultset.getString(1));
				eventBean.setCustomerName(resultset.getString(2));
				eventBean.setPhoneNumber(resultset.getString(3));
				eventBean.setAddress(resultset.getString(4));
				
				
				eventBean.setPayAmount(resultset.getDouble(5));
				eventBean.setBookingDate(resultset.getDate(6));
				eventList.add(eventBean);
				
				eventCount++;
			}			
			
		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			throw new EventException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				throw new EventException("Error in closing db connection");

			}
		}
		
		if( eventCount == 0)
			return null;
		else
			return eventList;
	}
		
	}

	


