package com.cg.event.exception;

public class EventException extends Exception {

	public EventException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
