package com.cg.event.pl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.event.bean.EventBean;
import com.cg.event.exception.EventException;
import com.cg.event.service.EventServiceImpl;
import com.cg.event.service.IEventService;

public class EventMain {
	static Scanner sc = new Scanner(System.in);
	static IEventService eventService = null;
	static EventServiceImpl eventServiceImpl = null;

	public static void main(String[] args) throws EventException, SQLException, ClassNotFoundException, IOException {
        // TODO Auto-generated method stub
        EventBean eventBean = null;
        String customerId = null;
        int option = 0;
        double amount = 0;
        while (true) {
            System.out.println();
            System.out.println();
            System.out.println("SLEEK ORGANIZERS");
            System.out.println("________________________________");
            
            System.out.println("1.EVENT SELECTION AND ADDING");
            
            System.out.println("2.VIEW CUSTOMER");
            System.out.println("3.RETRIVE  CUSTOMERS");
            System.out.println("4.EXIT APPLICATION");

            
            EventBean event = new EventBean();

            try {
            	
                option = sc.nextInt();
                
                switch (option) {
                    
                       
                    case 1:
                        while (eventBean == null) {

                            eventBean = populateEventBean();

                        }
                        try {
                            eventService = new EventServiceImpl();
                            customerId = eventServiceImpl.addEvent(eventBean);
                            System.out.println("Customer details has been successfully registered");
                            System.out.println("Customer id is :" + customerId);
                            
                        } 
                        finally {
                            customerId = null;
                            eventService = null;
                            eventBean = null;
                        }
                     
                    
                    	System.out.println("1.OFFICIAL EVENTS");
                        System.out.println("2.UNOFFICIAL EVENTS ");
                        
                        int choice = sc.nextInt();
                        switch (choice) {
                            case 1:
                                System.out.println("OFFICIAL EVENTS:");
                                System.out.println("1.corporate events " );
                                System.out.println( " 2.Board Meetings ");
                                System.out.println("enter your event type");
                                int ch=sc.nextInt();
                                switch(ch)
                                {
                                case 1:
                               	 System.out.println("enter the expected count");
                               	 int count=sc.nextInt();
                                double amt1= calc1(count);
                                System.out.println("your expected amount is "+ amt1);
                                 break;
                                
                                case 2:
                                  	 
                                	System.out.println("enter the expected count");
                            
                                	int count1=sc.nextInt();
                                  	double amt2 = calc2(count1);
                                    System.out.println("your expected amount is "+ amt2);
                                    break;
                              
                                }
                                
                               break;
                                
                            case 2:
                                System.out.println("UNOFFICIAL EVENTS:");
                                System.out.println("1.family parties");
                                System.out.println(" 2. bachelor parties ");
                                System.out.println("enter your event type");
                                int a=sc.nextInt();
                                switch(a)
                                {
                                case 1:
                               	 System.out.println("enter the expected count");
                               	 int count=sc.nextInt();
                               	double amt3 = calc2(count);
                                System.out.println("your expected amount is "+ amt3);
                                 break;
                                
                                case 2:
                                  	 
                                	System.out.println("enter the expected count");
                                  	int count1=sc.nextInt();
                                  	double amt4 = calc2(count1);
                                    System.out.println("your expected amount is "+ amt4);
                                    break;
                              
                                }
                                
                                
                                break;

                        }
                        break;

                    case 2:
                        System.out.println("enter Customer_id");
                        customerId = sc.next();
                        eventService = new EventServiceImpl();
                        eventBean = eventService.viewEventDetails(customerId);
                        System.out.println(eventBean);
                         
                        break;
                    case 3:

                        

                            
                     
                            try {
                                eventService =new EventServiceImpl();
                                List < EventBean > eventlist = new ArrayList < EventBean > ();
                                eventlist = eventService.retrieveAll();
                                if (eventlist != null)

                                {
                                    Iterator < EventBean > i = eventlist.iterator();
                                    while (i.hasNext()) 
                                    {
                                        System.out.println(i.next());
                                    }
                                    


                                }
                                else
                                {

                                   System.out.println("there is no customer details");
                               }


                            } catch (EventException ee) {
                                System.out.println("error " + ee.getMessage());
                                ee.printStackTrace();
                            }
                        

                        break;
                    case 4:
                    	System.out.println("exit application");
                    	System.out.println("______________________________");
                        System.out.println("THANKS FOR YOUR BOOKING VISIT AGAIN");
                        System.exit(0);

                        break;
                    default:
                        System.out.println("enter a valid option!");
                }

                }
             catch (InputMismatchException e) {
              sc.nextLine();
              System.err.println("please enter  a numeric value");
              
            }
            break;


        }

	}

	private static EventBean populateEventBean() {
		// TODO Auto-generated method stub
		EventBean eventBean = new EventBean();
		System.out.println("Enter details");
		System.out.println("Enter the customer name:");
		eventBean.setCustomerName(sc.next());
		System.out.println("Enter the Customer Contact");
		eventBean.setPhoneNumber(sc.next());
		System.out.println("Enter the customer Address");
		eventBean.setAddress(sc.next());
		eventServiceImpl = new EventServiceImpl();
		try {
			if (eventServiceImpl.validateEvent(eventBean))
				;
			return eventBean;

		} catch (EventException eventException) {
			System.out.println("invalid data");
			System.err.println(eventException.getMessage() + "\n try again");
			eventException.printStackTrace();
			System.exit(0);
		}

		return null;
	}

	static double calc1(int count) {

		double amount = count * 500;

		return amount;
	}

	static double calc2(int count1) {

		double amount = count1 * 600;

		return amount;

	}
	static double calc3(int count) {

		double amount = count * 600;

		return amount;

	}
	static double calc4(int count1) {

		double amount = count1 * 600;

		return amount;

	}

}